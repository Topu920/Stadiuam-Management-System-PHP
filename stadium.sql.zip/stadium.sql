--
-- Database: `stadium`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `tran_number` int(11) NOT NULL,
  `tran_date` date NOT NULL,
  `tran_type` varchar(8) DEFAULT NULL,
  `client_name` varchar(25) DEFAULT NULL,
  `cont_number` varchar(20) DEFAULT NULL,
  `balance` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`tran_number`, `tran_date`, `tran_type`, `client_name`, `cont_number`, `balance`) VALUES
(1, '2015-05-01', 'income', 'faruk', '123456789', 1000000),
(10, '2015-07-10', 'cost', 'forhad', '134679258', 5070500),
(15, '2015-10-15', 'income', 'shahir', '147852369', 10203000),
(20, '2016-02-01', 'cost', 'arif', '159357456', 15070200),
(25, '2016-07-20', 'income', 'tupo', '951258763', 203080992);

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `pass`) VALUES
(1, 'topu920@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `audience`
--

CREATE TABLE `audience` (
  `aud_seat_no` varchar(11) NOT NULL,
  `aud_name` varchar(25) DEFAULT NULL,
  `aud_gender` varchar(25) DEFAULT NULL,
  `aud_types` varchar(25) DEFAULT NULL,
  `aud_cell_num` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `audience`
--

INSERT INTO `audience` (`aud_seat_no`, `aud_name`, `aud_gender`, `aud_types`, `aud_cell_num`) VALUES
('a1', 'farhad', 'male', 'vip', '0171111111'),
('a2', 'topu', 'male', 'general', '0172222222'),
('a3', 'shahir', 'male', 'general', '01833333333'),
('a4', 'sakila', 'female', 'general', '01644444444'),
('a5', 'faruk', 'male', 'general', '01566666666');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `E_ID` int(11) NOT NULL,
  `E_NAME` varchar(30) NOT NULL,
  `E_CELL_NUM` varchar(11) NOT NULL,
  `E_MAIL` varchar(30) NOT NULL,
  `E_ADDRESS` varchar(30) DEFAULT NULL,
  `E_DESIGNATION` varchar(20) NOT NULL,
  `E_JOINING_DATE` date NOT NULL,
  `E_SALARY` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`E_ID`, `E_NAME`, `E_CELL_NUM`, `E_MAIL`, `E_ADDRESS`, `E_DESIGNATION`, `E_JOINING_DATE`, `E_SALARY`) VALUES
(1, 'Shahir', '123456', 'sahirkhan@gmail.com', 'Dhaka', 'Officer', '2017-02-20', 50000),
(2, 'Tofiqur Rahman', '654321', 'topu920@gmail.com', 'Uttara,Dhaka', 'S.Officer', '2016-03-20', 55000),
(3, 'Faruk Hossain', '2016753', 'farukhossain@gmail.com', 'Gazipur', 'Accountant', '0000-00-00', 42000),
(4, 'Farhad Hossain', '2045162', 'forhad@gmail.com', 'Noakhali', 'Security Incharge', '2016-09-17', 35000),
(5, 'Sayda Parvin', '159753', 'saydasakila@gmail.com', 'Dhaka-1230', 'Manager', '2015-05-25', 80000);

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `Gal_name` varchar(30) NOT NULL,
  `Gal_type` varchar(20) DEFAULT NULL,
  `Gal_capacity` int(255) DEFAULT NULL,
  `Gal_tramway` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`Gal_name`, `Gal_type`, `Gal_capacity`, `Gal_tramway`) VALUES
('Chief', 'VVip', 20, 'Gate Ex 5'),
('Close Stars', 'Grand Stand', 100, 'Gate 3'),
('Honours', 'Vip', 50, 'Gate Ex 4'),
('Open view', 'Generic', 250, 'Gate 2'),
('Sky Light', 'Generic', 250, 'Gate 1');

-- --------------------------------------------------------

--
-- Table structure for table `game_schedule`
--

CREATE TABLE `game_schedule` (
  `sch_no` int(11) NOT NULL,
  `g_date` date DEFAULT NULL,
  `g_time` time DEFAULT NULL,
  `tour_name` varchar(50) DEFAULT NULL,
  `g_type` varchar(20) DEFAULT NULL,
  `ft_name` varchar(30) DEFAULT NULL,
  `op_name` varchar(30) DEFAULT NULL,
  `g_status` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `game_schedule`
--

INSERT INTO `game_schedule` (`sch_no`, `g_date`, `g_time`, `tour_name`, `g_type`, `ft_name`, `op_name`, `g_status`) VALUES
(1, '2017-11-15', '09:30:00', 'World Cup', 'T20', 'Bangladesh', 'Pakistan', 'Ban Win by 5 wickets '),
(2, '2017-12-05', '10:00:00', 'World Cup', 'ODI ', 'India', 'Australia ', 'Aus win by 10 wickets '),
(3, '2017-12-06', '12:00:00', 'World Cup', 'ODI ', 'Bangladesh', 'Australia ', 'Ban win by 3 wickets '),
(4, '2017-12-12', '08:00:00', 'World Cup', 'ODI ', 'Sri-lanka', 'West Indis ', 'Sir win by  15 runs '),
(5, '2017-12-30', '09:00:00', 'World Cup', 'ODI ', 'South Africa', 'Australia ', ' Aus win by 1 wickets ');

-- --------------------------------------------------------

--
-- Table structure for table `medic`
--

CREATE TABLE `medic` (
  `Slip_no` double NOT NULL,
  `P_name` varchar(30) DEFAULT NULL,
  `P_age` int(3) DEFAULT NULL,
  `P_Type` varchar(15) DEFAULT NULL,
  `Pcell_number` varchar(11) DEFAULT NULL,
  `Doc_name` varchar(30) DEFAULT NULL,
  `Dcell_num` varchar(11) DEFAULT NULL,
  `Treat_type` varchar(20) DEFAULT NULL,
  `TOF` varchar(20) DEFAULT NULL,
  `Total_cost` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medic`
--

INSERT INTO `medic` (`Slip_no`, `P_name`, `P_age`, `P_Type`, `Pcell_number`, `Doc_name`, `Dcell_num`, `Treat_type`, `TOF`, `Total_cost`) VALUES
(1, 'Arif', 21, 'Audience', '01812345678', 'Dr. Rifat', '01987456321', 'Emergency', 'nothing', 750),
(2, 'sakila', 18, 'V.I.P', '01622064668', 'Dr. Topu', '01689228860', 'Emergency', 'Surgery ', 20000),
(3, 'Forhad', 20, 'Audience', '01799729603', 'Dr. David', '01622886690', 'Physiotherapy', 'Bed,Saline', 1500),
(4, 'Shahir', 27, 'V.V.I.P', '01675244527', 'Dr. Mim', '01701864933', 'Heart attack', 'Ambulance', 20000),
(5, 'Faruk', 29, 'V.I.P', '01687456321', 'Dr. Samia', '01701010266', 'Headache', 'Nothing', 100);

-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

CREATE TABLE `vendor` (
  `SReg_num` double NOT NULL,
  `Org_name` varchar(20) DEFAULT NULL,
  `Org_Reg_num` double DEFAULT NULL,
  `Contact_num` varchar(11) DEFAULT NULL,
  `Email` varchar(20) DEFAULT NULL,
  `Service_type` varchar(20) DEFAULT NULL,
  `Ser_commment` varchar(10) DEFAULT NULL,
  `Contact_duration` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendor`
--

INSERT INTO `vendor` (`SReg_num`, `Org_name`, `Org_Reg_num`, `Contact_num`, `Email`, `Service_type`, `Ser_commment`, `Contact_duration`) VALUES
(101236, 'Seba (prvt) Ltd.', 1000030254, '1712345678', 'seba123@gmail.com', 'Stationery', 'GOOD', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`tran_number`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `audience`
--
ALTER TABLE `audience`
  ADD PRIMARY KEY (`aud_seat_no`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`E_ID`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`Gal_name`);

--
-- Indexes for table `game_schedule`
--
ALTER TABLE `game_schedule`
  ADD PRIMARY KEY (`sch_no`);

--
-- Indexes for table `medic`
--
ALTER TABLE `medic`
  ADD PRIMARY KEY (`Slip_no`);

--
-- Indexes for table `vendor`
--
ALTER TABLE `vendor`
  ADD PRIMARY KEY (`SReg_num`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `medic`
--
ALTER TABLE `medic`
  MODIFY `Slip_no` double NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
